import hashlib
import json
import py_compile
import re
import shutil
import tempfile
import zipfile
from pathlib import Path

REPO = "Tiopatinhas13/jarvis-updates"
BRANCH = "main"


def _version_tuple(v):
    nums = re.findall(r"\d+", str(v))
    return tuple(int(x) for x in nums) if nums else (0,)


def _downloads_dir():
    preferido = Path("/mnt/c/Users/sandr/Downloads")
    if preferido.exists():
        return preferido

    users = Path("/mnt/c/Users")
    if users.exists():
        for p in users.iterdir():
            d = p / "Downloads"
            if d.exists():
                return d

    raise RuntimeError("Não encontrei a pasta Downloads do Windows.")


def _sha256(path):
    h = hashlib.sha256()

    with open(path, "rb") as f:
        for bloco in iter(lambda: f.read(1024 * 1024), b""):
            h.update(bloco)

    return h.hexdigest()


def _detectar_versao_atual(jarvis_path):
    texto = Path(jarvis_path).read_text(encoding="utf-8")

    m = re.search(
        r'VERSAO_JARVIS\s*=\s*["\']([^"\']+)["\']',
        texto
    )

    if m:
        return m.group(1).strip()

    m = re.search(r"JARVIS\s+([0-9]+(?:\.[0-9]+)+)", texto)

    if m:
        return m.group(1).strip()

    return "0"


def _atualizar_versao_no_codigo(texto, nova_versao):
    texto = re.sub(
        r'(VERSAO_JARVIS\s*=\s*)["\'][^"\']+["\']',
        lambda m: f'{m.group(1)}"{nova_versao}"',
        texto,
        count=1,
    )

    texto = re.sub(
        r'JARVIS\s+\d+(?:\.\d+){1,3}\s+-\s+ASSISTENTE',
        f'JARVIS {nova_versao} - ASSISTENTE',
        texto,
        count=1,
    )

    return texto


def preparar(base_dir, nova_versao, notas=""):
    base_dir = Path(base_dir)
    nova_versao = str(nova_versao).strip()

    if not re.fullmatch(r"\d+(?:\.\d+){1,3}", nova_versao):
        return {
            "ok": False,
            "mensagem": "Versão inválida. Use formato como 8.4 ou 8.4.1."
        }

    jarvis = base_dir / "jarvis.py"

    if not jarvis.exists():
        return {
            "ok": False,
            "mensagem": "jarvis.py não encontrado."
        }

    versao_atual = _detectar_versao_atual(jarvis)

    if _version_tuple(nova_versao) <= _version_tuple(versao_atual):
        return {
            "ok": False,
            "mensagem": (
                f"A nova versão {nova_versao} precisa ser maior "
                f"que a atual {versao_atual}."
            )
        }

    downloads = _downloads_dir()
    nome_zip = f"JARVIS_UPDATE_{nova_versao.replace('.', '_')}.zip"
    nome_manifest = f"manifest_{nova_versao.replace('.', '_')}.json"

    zip_destino = downloads / nome_zip
    manifest_destino = downloads / nome_manifest

    temp_root = Path(tempfile.mkdtemp(prefix="jarvis_build_"))
    stage = temp_root / "stage"
    stage.mkdir(parents=True, exist_ok=True)

    try:
        texto = jarvis.read_text(encoding="utf-8")
        texto = _atualizar_versao_no_codigo(texto, nova_versao)
        (stage / "jarvis.py").write_text(texto, encoding="utf-8")

        auxiliares = [
            "jarvis_config.json",
            "jarvis_updater.py",
            "jarvis_publisher.py",
            "jarvis_builder.py",
            "jarvis_maintenance.py",
        ]

        for nome in auxiliares:
            origem = base_dir / nome

            if origem.exists():
                shutil.copy2(origem, stage / nome)

        (stage / "VERSION").write_text(
            nova_versao + "\n",
            encoding="utf-8"
        )

        # Validação estrutural permanente.
        jarvis_stage = stage / "jarvis.py"
        codigo_stage = jarvis_stage.read_text(encoding="utf-8")

        if '"updates"' not in codigo_stage and "'updates'" not in codigo_stage:
            raise RuntimeError(
                "Build bloqueado: suporte à configuração updates não foi encontrado."
            )

        py_compile.compile(
            str(stage / "jarvis.py"),
            doraise=True
        )

        for nome in [
            "jarvis_updater.py",
            "jarvis_publisher.py",
            "jarvis_builder.py",
            "jarvis_maintenance.py",
        ]:
            p = stage / nome

            if p.exists():
                py_compile.compile(str(p), doraise=True)

        if zip_destino.exists():
            zip_destino.unlink()

        with zipfile.ZipFile(
            zip_destino,
            "w",
            compression=zipfile.ZIP_DEFLATED
        ) as z:
            for arquivo in stage.iterdir():
                if arquivo.is_file():
                    z.write(arquivo, arcname=arquivo.name)

        sha = _sha256(zip_destino)

        manifest = {
            "version": nova_versao,
            "package_url": (
                f"https://raw.githubusercontent.com/"
                f"{REPO}/{BRANCH}/{nome_zip}"
            ),
            "sha256": sha,
            "notes": notas.strip() or (
                f"Versão {nova_versao} preparada automaticamente pelo Jarvis."
            ),
        }

        manifest_destino.write_text(
            json.dumps(
                manifest,
                ensure_ascii=False,
                indent=2
            ),
            encoding="utf-8"
        )

        return {
            "ok": True,
            "versao": nova_versao,
            "versao_atual": versao_atual,
            "zip": str(zip_destino),
            "zip_nome": nome_zip,
            "manifest": str(manifest_destino),
            "manifest_nome": nome_manifest,
            "sha256": sha,
        }

    except Exception as erro:
        return {
            "ok": False,
            "mensagem": str(erro),
        }

    finally:
        shutil.rmtree(temp_root, ignore_errors=True)
