from pathlib import Path
from datetime import datetime
import difflib
import json
import py_compile
import shutil
import tempfile
import zipfile

PROJETO = Path.home() / "jarvis"
PATCH_TEST_MARKER = "maintenance-test-ok"
DOWNLOADS_PADRAO = Path("/mnt/c/Users/sandr/Downloads")

ARQUIVOS_PERMITIDOS = {
    "jarvis.py",
    "jarvis_config.json",
    "jarvis_updater.py",
    "jarvis_publisher.py",
    "jarvis_builder.py",
    "jarvis_maintenance.py",
    "VERSION",
}


def _downloads():
    if DOWNLOADS_PADRAO.exists():
        return DOWNLOADS_PADRAO

    users = Path("/mnt/c/Users")
    if users.exists():
        for p in users.iterdir():
            d = p / "Downloads"
            if d.exists():
                return d

    raise RuntimeError("Pasta Downloads não encontrada.")


def _mais_recente():
    arquivos = sorted(
        _downloads().glob("JARVIS_PATCH_*.zip"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return arquivos[0] if arquivos else None


def _ler_manifest(z):
    nomes = set(z.namelist())

    if "patch_manifest.json" not in nomes:
        raise RuntimeError("patch_manifest.json ausente no pacote.")

    dados = json.loads(
        z.read("patch_manifest.json").decode("utf-8")
    )

    arquivos = dados.get("files") or []

    if not isinstance(arquivos, list) or not arquivos:
        raise RuntimeError("Manifesto sem lista de arquivos.")

    for nome in arquivos:
        if nome not in ARQUIVOS_PERMITIDOS:
            raise RuntimeError(f"Arquivo não permitido no patch: {nome}")

        if nome not in nomes:
            raise RuntimeError(f"Arquivo listado mas ausente no ZIP: {nome}")

    return dados


def _validar_python(stage, arquivos):
    for nome in arquivos:
        if nome.endswith(".py"):
            py_compile.compile(str(stage / nome), doraise=True)


def _diff_resumido(stage, arquivos, limite=80):
    saida = []

    for nome in arquivos:
        if not nome.endswith((".py", ".json", "VERSION")):
            continue

        novo = stage / nome
        atual = PROJETO / nome

        novo_txt = novo.read_text(
            encoding="utf-8",
            errors="replace"
        ).splitlines()

        atual_txt = []
        if atual.exists():
            atual_txt = atual.read_text(
                encoding="utf-8",
                errors="replace"
            ).splitlines()

        diff = list(
            difflib.unified_diff(
                atual_txt,
                novo_txt,
                fromfile=f"atual/{nome}",
                tofile=f"novo/{nome}",
                lineterm="",
                n=2,
            )
        )

        if diff:
            saida.append(f"\n--- {nome} ---")
            saida.extend(diff[:limite])

            if len(diff) > limite:
                saida.append(
                    f"... {len(diff) - limite} linhas de diff omitidas ..."
                )

    return "\n".join(saida).strip()


def preparar_patch():
    pacote = _mais_recente()

    if pacote is None:
        return {
            "ok": False,
            "mensagem": "Nenhum JARVIS_PATCH_*.zip encontrado em Downloads.",
        }

    temp = Path(tempfile.mkdtemp(prefix="jarvis_patch_stage_"))
    stage = temp / "stage"
    stage.mkdir(parents=True)

    try:
        with zipfile.ZipFile(pacote, "r") as z:
            manifest = _ler_manifest(z)
            arquivos = manifest["files"]

            for nome in arquivos:
                destino = stage / nome
                destino.parent.mkdir(parents=True, exist_ok=True)
                destino.write_bytes(z.read(nome))

        _validar_python(stage, arquivos)
        diff = _diff_resumido(stage, arquivos)

        return {
            "ok": True,
            "pacote": str(pacote),
            "temp": str(temp),
            "stage": str(stage),
            "manifest": manifest,
            "arquivos": arquivos,
            "diff": diff,
        }

    except Exception as erro:
        shutil.rmtree(temp, ignore_errors=True)
        return {
            "ok": False,
            "mensagem": str(erro),
        }


def aplicar_patch(preparo):
    if not preparo.get("ok"):
        return {
            "ok": False,
            "mensagem": "Patch não preparado.",
        }

    stage = Path(preparo["stage"])
    arquivos = preparo["arquivos"]

    carimbo = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = PROJETO / "backups" / f"maintenance_{carimbo}"
    backup_dir.mkdir(parents=True, exist_ok=True)

    try:
        for nome in arquivos:
            atual = PROJETO / nome
            if atual.exists():
                shutil.copy2(atual, backup_dir / nome)

        for nome in arquivos:
            shutil.copy2(stage / nome, PROJETO / nome)

        for nome in arquivos:
            if nome.endswith(".py"):
                py_compile.compile(
                    str(PROJETO / nome),
                    doraise=True
                )

        return {
            "ok": True,
            "backup": str(backup_dir),
            "arquivos": arquivos,
        }

    except Exception as erro:
        for nome in arquivos:
            salvo = backup_dir / nome
            destino = PROJETO / nome

            if salvo.exists():
                shutil.copy2(salvo, destino)

        return {
            "ok": False,
            "mensagem": str(erro),
            "backup": str(backup_dir),
        }

    finally:
        shutil.rmtree(Path(preparo["temp"]), ignore_errors=True)
