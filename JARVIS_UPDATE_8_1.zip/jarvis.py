import asyncio
import base64
import json
import os
import re
import statistics
import subprocess
import sys
import time
import unicodedata
import urllib.request
from urllib.parse import quote_plus
from pathlib import Path
import threading
import queue
import wave
from array import array
from collections import deque
from datetime import datetime
from difflib import SequenceMatcher

import edge_tts
from faster_whisper import WhisperModel

import jarvis_updater


# =========================================================
# JARVIS 8.1 - AÇÕES PRÁTICAS + INTENÇÕES + ROTINAS
# =========================================================

ARQUIVO_AUDIO = "/tmp/jarvis_audio.wav"
ARQUIVO_RESPOSTA = "/tmp/jarvis_resposta.mp3"

ARQUIVO_NOTAS = Path.home() / "jarvis" / "notas_jarvis.txt"
temporizadores_ativos = []

MODELO_IA = "llama3.2:3b"
OLLAMA_URL = "http://127.0.0.1:11434/api/generate"
VERSAO_JARVIS = "8.1"


BASE_DIR = Path(__file__).resolve().parent
ARQUIVO_CONFIG = BASE_DIR / "jarvis_config.json"

CONFIG_PADRAO = {
    "sites": {
        "google": "https://www.google.com",
        "youtube": "https://www.youtube.com",
        "chatgpt": "https://chatgpt.com",
        "gmail": "https://mail.google.com"
    },
    "programas": {
        "bloco_notas": "notepad.exe",
        "calculadora": "calc.exe",
        "explorador": "explorer.exe",
        "paint": "mspaint.exe",
        "chrome": "chrome.exe"
    },
    "pastas": {
        "downloads": "Downloads",
        "documentos": "Documents",
        "desktop": "Desktop",
        "imagens": "Pictures",
        "musicas": "Music",
        "videos": "Videos"
    },
    "rotinas": {
        "comecar trabalho": [
            {"tipo": "site", "alvo": "chatgpt"},
            {"tipo": "site", "alvo": "gmail"},
            {"tipo": "pasta", "alvo": "documentos"}
        ],
        "modo consulta": [
            {"tipo": "site", "alvo": "chatgpt"},
            {"tipo": "programa", "alvo": "bloco_notas"},
            {"tipo": "pasta", "alvo": "documentos"}
        ],
        "modo estudo": [
            {"tipo": "site", "alvo": "chatgpt"},
            {"tipo": "programa", "alvo": "bloco_notas"}
        ]
    }
}


def carregar_config():
    try:
        if ARQUIVO_CONFIG.exists():
            with ARQUIVO_CONFIG.open("r", encoding="utf-8") as arquivo:
                dados = json.load(arquivo)

            config = CONFIG_PADRAO.copy()

            for chave in ("sites", "programas", "pastas", "rotinas"):
                if isinstance(dados.get(chave), dict):
                    config[chave] = dados[chave]

            return config

    except Exception as erro:
        print(f"[Aviso: falha ao carregar config: {erro}]")

    try:
        with ARQUIVO_CONFIG.open("w", encoding="utf-8") as arquivo:
            json.dump(
                CONFIG_PADRAO,
                arquivo,
                ensure_ascii=False,
                indent=2,
            )
    except Exception as erro:
        print(f"[Aviso: não foi possível criar config padrão: {erro}]")

    return CONFIG_PADRAO.copy()


CONFIG = carregar_config()

TAXA_AUDIO = 16000
CANAIS = 1


# =========================================================
# WAKE WORD "JARVIS" VIA WHISPER SMALL
# =========================================================

ARQUIVO_WAKE = "/tmp/jarvis_wake.wav"

# O detector só chama o Whisper Small quando realmente escuta uma fala.
# Isso evita usar CPU continuamente durante o silêncio.
WAKE_CHUNKS_CALIBRACAO = 15
WAKE_CHUNKS_PRE_ROLL = 20
WAKE_CHUNKS_SILENCIO_FINAL = 30   # ~0,60 s
WAKE_CHUNKS_MAXIMOS = 175         # ~3,5 s

# Quanto menor, mais permissivo. 0,72 costuma tolerar erros pequenos
# do Whisper sem aceitar palavras muito diferentes.
WAKE_SIMILARIDADE_MINIMA = 0.72

# Pequena lista de variações que o Whisper pode produzir para "Jarvis".
WAKE_VARIACOES = {
    "jarvis",
    "javis",
    "jarves",
    "jervis",
    "djarvis",
    "jarves",
    "jarvys",
    "jarviz",
}


# =========================================================
# VAD / CONVERSA
# =========================================================

CHUNK_MS = 20
AMOSTRAS_POR_CHUNK = int(TAXA_AUDIO * CHUNK_MS / 1000)
BYTES_POR_CHUNK = AMOSTRAS_POR_CHUNK * 2

CHUNKS_CALIBRACAO = 10
CHUNKS_PRE_ROLL = 20
CHUNKS_SILENCIO_FINAL = 35    # ~0,70 s
CHUNKS_MAXIMOS_FALA = 1250    # ~25 s

ESPERA_PRIMEIRA_PERGUNTA = 15
ESPERA_CONTINUACAO = 20


# =========================================================
# MEMÓRIA CURTA
# =========================================================

# 8 mensagens = aproximadamente 4 trocas.
# Mantém contexto sem inflar demais o prompt local.
memoria = deque(maxlen=8)


# =========================================================
# WHISPER
# =========================================================

HOTWORDS = (
    "Jarvis Sandro "
    "blockchain DeFi Bitcoin Ethereum "
    "inteligência artificial aprendizado de máquina "
    "Medicina Chinesa acupuntura "
    "desligar sistema encerrar repousar "
    "atualização atualizar versão rollback "
    "verificar atualização"
)


# =========================================================
# TEXTO
# =========================================================

def normalizar_comando(texto):
    texto = texto.lower()
    texto = unicodedata.normalize("NFD", texto)
    texto = "".join(
        caractere
        for caractere in texto
        if unicodedata.category(caractere) != "Mn"
    )
    texto = re.sub(r"[^\w\s]", " ", texto)
    texto = re.sub(r"\s+", " ", texto)
    return texto.strip()


def similaridade_palavra(a, b):
    return SequenceMatcher(None, a, b).ratio()


def detectar_jarvis_no_texto(texto):
    """
    Procura Jarvis nas primeiras palavras da transcrição.
    Retorna (detectado, melhor_score, melhor_palavra).
    """
    normalizado = normalizar_comando(texto)

    if not normalizado:
        return False, 0.0, ""

    palavras = normalizado.split()

    # O wake deve estar no começo da frase.
    # Ignoramos partículas comuns inseridas pelo Whisper.
    candidatos = palavras[:3]

    melhores = []

    for palavra in candidatos:
        if palavra in {"ei", "hey", "hei", "oi", "em"}:
            continue

        if palavra in WAKE_VARIACOES:
            melhores.append((1.0, palavra))
            continue

        score = max(
            similaridade_palavra(palavra, variacao)
            for variacao in WAKE_VARIACOES
        )

        melhores.append((score, palavra))

    if not melhores:
        return False, 0.0, ""

    melhor_score, melhor_palavra = max(melhores, key=lambda item: item[0])

    return (
        melhor_score >= WAKE_SIMILARIDADE_MINIMA,
        melhor_score,
        melhor_palavra,
    )


def e_apenas_wake_word(texto):
    """True quando a fala é essencialmente apenas o chamado Jarvis."""
    n = normalizar_comando(texto)

    if not n:
        return True

    detectado, _, _ = detectar_jarvis_no_texto(texto)

    if not detectado:
        return False

    palavras = n.split()

    # Jarvis sozinho ou com uma pequena partícula antes.
    return len(palavras) <= 2


def remover_wake_word(texto):
    """Remove o chamado Jarvis do início mesmo com pequena distorção do Whisper."""
    if e_apenas_wake_word(texto):
        return ""

    normalizado = normalizar_comando(texto)
    palavras_norm = normalizado.split()

    if not palavras_norm:
        return texto.strip()

    # Localiza, nas primeiras três palavras, aquela que mais se parece com Jarvis.
    limite = min(3, len(palavras_norm))
    melhor_indice = None
    melhor_score = 0.0

    for i in range(limite):
        palavra = palavras_norm[i]

        if palavra in {"ei", "hey", "hei", "oi", "em"}:
            continue

        score = max(
            similaridade_palavra(palavra, variacao)
            for variacao in WAKE_VARIACOES
        )

        if score > melhor_score:
            melhor_score = score
            melhor_indice = i

    if melhor_indice is None or melhor_score < WAKE_SIMILARIDADE_MINIMA:
        return texto.strip()

    # Remove a partícula opcional + o wake da frase original.
    tokens_originais = texto.strip().split()

    remover_ate = melhor_indice + 1
    if remover_ate <= len(tokens_originais):
        restante = " ".join(tokens_originais[remover_ate:])
        return restante.strip(" ,.:;!?-")

    return ""


def limpar_texto_para_fala(texto):
    texto = re.sub(
        r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])",
        "",
        texto,
    )
    texto = "".join(
        caractere
        for caractere in texto
        if caractere.isprintable() or caractere in "\n "
    )
    texto = texto.replace("**", "").replace("__", "").replace("`", "")
    texto = re.sub(r"(?m)^\s*[-•*]\s*", "", texto)
    texto = re.sub(r"(?m)^\s*\d+\s*[\.\)\-:]\s*", "", texto)
    texto = re.sub(r"\s*\n+\s*", " ", texto)
    texto = re.sub(r"\s{2,}", " ", texto)
    return texto.strip()


# =========================================================
# VOZ - STREAMING EDGE TTS
# =========================================================

async def gerar_e_tocar_voz_stream(texto):
    """Começa a reproduzir assim que os primeiros bytes do TTS chegam."""
    comunicacao = edge_tts.Communicate(
        texto,
        voice="pt-BR-AntonioNeural",
        rate="+20%",
    )

    player = subprocess.Popen(
        [
            "ffplay",
            "-nodisp",
            "-autoexit",
            "-loglevel",
            "quiet",
            "-i",
            "pipe:0",
        ],
        stdin=subprocess.PIPE,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    primeiro_audio = None

    try:
        async for chunk in comunicacao.stream():
            if chunk["type"] == "audio":
                if primeiro_audio is None:
                    primeiro_audio = time.perf_counter()
                try:
                    player.stdin.write(chunk["data"])
                    player.stdin.flush()
                except (BrokenPipeError, OSError):
                    break
    finally:
        try:
            if player.stdin:
                player.stdin.close()
        except Exception:
            pass

        try:
            player.wait(timeout=30)
        except subprocess.TimeoutExpired:
            player.kill()

    return primeiro_audio


async def gerar_voz_arquivo(texto):
    comunicacao = edge_tts.Communicate(
        texto,
        voice="pt-BR-AntonioNeural",
        rate="+20%",
    )
    await comunicacao.save(ARQUIVO_RESPOSTA)


def falar(texto):
    texto_limpo = limpar_texto_para_fala(texto)
    if not texto_limpo:
        return

    print(f"JARVIS: {texto_limpo}")
    inicio = time.perf_counter()

    try:
        primeiro_audio = asyncio.run(
            gerar_e_tocar_voz_stream(texto_limpo)
        )

        fim = time.perf_counter()
        if primeiro_audio is not None:
            inicio_voz = primeiro_audio - inicio
            print(f"⏱️  TTS início da voz: {inicio_voz:.2f}s")
        print(f"⏱️  TTS total: {fim - inicio:.2f}s")

    except Exception as erro:
        print(f"[Streaming TTS falhou: {erro}]")
        print("[Usando modo de voz de reserva]")

        try:
            asyncio.run(gerar_voz_arquivo(texto_limpo))
            subprocess.run(
                [
                    "ffplay",
                    "-nodisp",
                    "-autoexit",
                    "-loglevel",
                    "quiet",
                    ARQUIVO_RESPOSTA,
                ],
                check=False,
            )
            print(f"⏱️  TTS fallback: {time.perf_counter() - inicio:.2f}s")
        except Exception as erro_fallback:
            print(f"[Erro de voz: {erro_fallback}]")


# =========================================================
# MEMÓRIA
# =========================================================

def registrar_memoria(papel, texto):
    memoria.append({"papel": papel, "texto": texto})


def montar_historico():
    if not memoria:
        return "Nenhuma conversa anterior nesta sessão."

    linhas = []
    for item in memoria:
        nome = "Sandro" if item["papel"] == "usuario" else "Jarvis"
        linhas.append(f"{nome}: {item['texto']}")
    return "\n".join(linhas)


# =========================================================
# OLLAMA / LLAMA
# =========================================================

def requisicao_ollama(prompt, num_predict=120, temperatura=0.35, timeout=90):
    dados = {
        "model": MODELO_IA,
        "prompt": prompt,
        "stream": False,
        "keep_alive": "30m",
        "options": {
            "temperature": temperatura,
            "num_predict": num_predict,
            "num_ctx": 2048,
        },
    }

    requisicao = urllib.request.Request(
        OLLAMA_URL,
        data=json.dumps(dados).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    with urllib.request.urlopen(requisicao, timeout=timeout) as resposta_http:
        return json.loads(resposta_http.read().decode("utf-8"))


def aquecer_ollama():
    print("🔥 Aquecendo o cérebro local...")
    inicio = time.perf_counter()

    try:
        requisicao_ollama(
            "Responda somente: OK",
            num_predict=2,
            temperatura=0.0,
            timeout=120,
        )
        print(f"🔥 Llama pronto em {time.perf_counter() - inicio:.2f}s")
    except Exception as erro:
        print(f"[Aviso: não consegui pré-aquecer o Llama: {erro}]")



def montar_prompt(pergunta):
    historico = montar_historico()

    return f"""
Você é Jarvis, assistente pessoal de Sandro.
Responda sempre em português brasileiro.
Sua resposta será reproduzida por voz.

Use a conversa recente apenas quando a nova pergunta depender dela.
Se Sandro disser "e por quê?", "explique melhor", "e nesse caso?" ou algo
semelhante, use o contexto recente.

Regras:
- responda de maneira natural e direta;
- prefira respostas curtas, normalmente uma a três frases;
- use texto corrido;
- não use listas, Markdown ou títulos;
- não diga que você é Llama ou um modelo de linguagem;
- não mencione Meta ou Ollama salvo se Sandro perguntar.

CONVERSA RECENTE:
{historico}

PERGUNTA:
{pergunta}

RESPOSTA:
"""


def produtor_ollama_stream(prompt, fila, estado):
    """
    Lê o stream do Ollama em uma thread separada.
    Assim o Llama pode continuar gerando enquanto o Jarvis já fala.
    """
    dados = {
        "model": MODELO_IA,
        "prompt": prompt,
        "stream": True,
        "keep_alive": "30m",
        "options": {
            "temperature": 0.35,
            "num_predict": 120,
            "num_ctx": 2048,
        },
    }

    requisicao = urllib.request.Request(
        OLLAMA_URL,
        data=json.dumps(dados).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(requisicao, timeout=90) as resposta_http:
            for linha in resposta_http:
                if not linha:
                    continue

                pacote = json.loads(linha.decode("utf-8"))
                trecho = pacote.get("response", "")

                if trecho:
                    fila.put(trecho)

                if pacote.get("done"):
                    break

    except Exception as erro:
        estado["erro"] = erro

    finally:
        fila.put(None)


def extrair_frases_prontas(buffer):
    """
    Separa frases completas para o TTS.
    Mantém o restante incompleto no buffer.
    """
    frases = []

    # Pontuação forte: boa para iniciar a fala rapidamente sem picotar demais.
    padrao = re.compile(r"(.+?[.!?])(?:\s+|$)", re.S)

    posicao = 0

    for match in padrao.finditer(buffer):
        frase = match.group(1).strip()

        if frase:
            frases.append(frase)

        posicao = match.end()

    restante = buffer[posicao:].strip()

    return frases, restante


def pensar_e_falar_stream(pergunta):
    """
    Fluxo principal de IA:
    Ollama gera em streaming e o TTS começa na primeira frase pronta.
    Retorna o texto completo para a memória.
    """
    prompt = montar_prompt(pergunta)

    fila = queue.Queue()
    estado = {"erro": None}

    thread = threading.Thread(
        target=produtor_ollama_stream,
        args=(prompt, fila, estado),
        daemon=True,
    )

    inicio = time.perf_counter()
    thread.start()

    buffer = ""
    resposta_completa = ""
    primeira_fala_iniciada = False

    while True:
        trecho = fila.get()

        if trecho is None:
            break

        resposta_completa += trecho
        buffer += trecho

        frases, buffer = extrair_frases_prontas(buffer)

        for frase in frases:
            if not primeira_fala_iniciada:
                print(
                    f"⚡ Primeira frase do Llama pronta em "
                    f"{time.perf_counter() - inicio:.2f}s"
                )
                primeira_fala_iniciada = True

            falar(frase)

    # Fala qualquer resto que não terminou com ponto.
    buffer = buffer.strip()

    if buffer:
        if not primeira_fala_iniciada:
            print(
                f"⚡ Primeira resposta do Llama pronta em "
                f"{time.perf_counter() - inicio:.2f}s"
            )
        falar(buffer)

    thread.join(timeout=1)

    tempo_total = time.perf_counter() - inicio
    print(f"⏱️  Llama + fala em streaming: {tempo_total:.2f}s")

    if estado["erro"]:
        print(f"[Erro do cérebro local: {estado['erro']}]")

        if not resposta_completa.strip():
            falar("Tive um problema ao processar sua pergunta.")
            return "Tive um problema ao processar sua pergunta."

    resposta_completa = resposta_completa.strip()

    if not resposta_completa:
        resposta_completa = "Não consegui formular uma resposta agora."
        falar(resposta_completa)

    return resposta_completa


def pensar(pergunta):
    """Fallback não-streaming."""
    prompt = montar_prompt(pergunta)
    inicio = time.perf_counter()

    try:
        resposta_json = requisicao_ollama(prompt)
        resposta = resposta_json.get("response", "").strip()
        print(f"⏱️  Llama: {time.perf_counter() - inicio:.2f}s")

        if resposta:
            return resposta

        return "Não consegui formular uma resposta agora."

    except Exception as erro:
        print(f"⏱️  Llama falhou após {time.perf_counter() - inicio:.2f}s")
        print(f"[Erro do cérebro local: {erro}]")
        return "Tive um problema ao processar sua pergunta."


# =========================================================
# RELÓGIO DO WINDOWS
# =========================================================

DIAS_SEMANA = {
    0: "domingo",
    1: "segunda-feira",
    2: "terça-feira",
    3: "quarta-feira",
    4: "quinta-feira",
    5: "sexta-feira",
    6: "sábado",
}


def obter_data_hora_windows():
    """Usa o relógio do Windows; faz fallback para o WSL se necessário."""
    try:
        comando = (
            "$d=Get-Date; "
            "Write-Output ($d.ToString('yyyy-MM-dd HH:mm:ss')); "
            "Write-Output ([int]$d.DayOfWeek)"
        )

        resultado = subprocess.run(
            ["powershell.exe", "-NoProfile", "-Command", comando],
            capture_output=True,
            text=True,
            timeout=5,
            check=True,
        )

        linhas = [
            linha.strip()
            for linha in resultado.stdout.splitlines()
            if linha.strip()
        ]

        if len(linhas) >= 2:
            dt = datetime.strptime(linhas[0], "%Y-%m-%d %H:%M:%S")
            indice_dia = int(linhas[1])
            return dt, indice_dia

    except Exception as erro:
        print(f"[Aviso: relógio do Windows indisponível: {erro}]")

    dt = datetime.now()
    # Python: segunda=0; converter para domingo=0
    indice_dia = (dt.weekday() + 1) % 7
    return dt, indice_dia


# =========================================================
# ÁUDIO
# =========================================================

def calcular_rms(dados):
    if not dados:
        return 0

    amostras = array("h", dados)
    if sys.byteorder != "little":
        amostras.byteswap()
    if not amostras:
        return 0

    soma = sum(amostra * amostra for amostra in amostras)
    return (soma / len(amostras)) ** 0.5


def salvar_wav(blocos):
    with wave.open(ARQUIVO_AUDIO, "wb") as arquivo_wav:
        arquivo_wav.setnchannels(CANAIS)
        arquivo_wav.setsampwidth(2)
        arquivo_wav.setframerate(TAXA_AUDIO)
        arquivo_wav.writeframes(b"".join(blocos))


def iniciar_microfone():
    return subprocess.Popen(
        [
            "ffmpeg",
            "-loglevel",
            "quiet",
            "-f",
            "pulse",
            "-i",
            "RDPSource",
            "-af",
            "highpass=f=80,lowpass=f=7500",
            "-ac",
            "1",
            "-ar",
            str(TAXA_AUDIO),
            "-f",
            "s16le",
            "pipe:1",
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
    )


def iniciar_microfone_wake():
    """
    Caminho de áudio exclusivo do wake word.
    O afftdn reduz ruído estacionário sem alterar o áudio principal das perguntas.
    """
    return subprocess.Popen(
        [
            "ffmpeg",
            "-loglevel",
            "quiet",
            "-f",
            "pulse",
            "-i",
            "RDPSource",
            "-af",
            "highpass=f=80,lowpass=f=7500,afftdn=nf=-20",
            "-ac",
            "1",
            "-ar",
            str(TAXA_AUDIO),
            "-f",
            "s16le",
            "pipe:1",
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
    )


def encerrar_microfone(processo):
    if processo is None:
        return

    processo.terminate()
    try:
        processo.wait(timeout=2)
    except subprocess.TimeoutExpired:
        processo.kill()


# =========================================================
# CARREGAMENTO DOS MODELOS
# =========================================================

print("Carregando Whisper Small...")
modelo_whisper = WhisperModel(
    "small",
    device="cpu",
    compute_type="int8",
)

# O mesmo modelo é usado tanto para o wake "Jarvis"
# quanto para transcrever as perguntas.


# =========================================================
# TRANSCRIÇÃO
# =========================================================

def transcrever():
    inicio = time.perf_counter()

    segmentos, _ = modelo_whisper.transcribe(
        ARQUIVO_AUDIO,
        language="pt",
        beam_size=3,
        temperature=0.0,
        vad_filter=True,
        condition_on_previous_text=False,
        no_speech_threshold=0.5,
        hotwords=HOTWORDS,
        initial_prompt=(
            "Conversa natural em português brasileiro. "
            "O usuário se chama Sandro e conversa com seu assistente Jarvis. "
            "Assuntos frequentes: tecnologia, inteligência artificial, "
            "blockchain, DeFi, Bitcoin, Ethereum, Medicina Chinesa e acupuntura. "
            "Comando de encerramento: desligar sistema."
        ),
    )

    texto = " ".join(segmento.text for segmento in segmentos).strip()
    print(f"⏱️  Whisper: {time.perf_counter() - inicio:.2f}s")
    return texto


def salvar_wav_em(caminho, blocos):
    with wave.open(caminho, "wb") as arquivo_wav:
        arquivo_wav.setnchannels(CANAIS)
        arquivo_wav.setsampwidth(2)
        arquivo_wav.setframerate(TAXA_AUDIO)
        arquivo_wav.writeframes(b"".join(blocos))


def transcrever_wake():
    """Transcrição leve e tolerante para identificar Jarvis em ambiente ruidoso."""
    inicio = time.perf_counter()

    segmentos_iter, _ = modelo_whisper.transcribe(
        ARQUIVO_WAKE,
        language="pt",
        beam_size=1,
        temperature=0.0,
        vad_filter=True,
        condition_on_previous_text=False,
        no_speech_threshold=0.60,
        initial_prompt=(
            "O usuário está chamando o assistente Jarvis. "
            "A palavra falada é Jarvis."
        ),
    )

    segmentos = list(segmentos_iter)

    texto_wake = " ".join(
        segmento.text
        for segmento in segmentos
    ).strip()

    print(
        f"👂 Wake ouvido: {texto_wake} "
        f"({time.perf_counter() - inicio:.2f}s)"
    )

    return texto_wake


# =========================================================
# WAKE WORD + CAPTURA DA FRASE
# =========================================================

def esperar_wake_e_capturar():
    """
    Fica em espera por voz.
    Quando alguém fala, grava uma frase curta e usa Whisper Tiny para verificar
    se a fala contém 'Jarvis'. Se houver uma pergunta na mesma frase,
    devolve o texto inteiro para o loop principal.
    """
    print("\n🟢 JARVIS em espera. Diga: Jarvis.")

    while True:
        processo = iniciar_microfone_wake()

        try:
            # Calibração rápida do ruído ambiente.
            niveis_ruido = []

            for _ in range(WAKE_CHUNKS_CALIBRACAO):
                dados = processo.stdout.read(BYTES_POR_CHUNK)
                if not dados:
                    break
                niveis_ruido.append(calcular_rms(dados))

            ruido_medio = (
                sum(niveis_ruido) / len(niveis_ruido)
                if niveis_ruido
                else 100
            )

            limite_voz = max(260, ruido_medio * 2.8)

            pre_roll = deque(maxlen=WAKE_CHUNKS_PRE_ROLL)
            audio_gravado = []

            fala_detectada = False
            chunks_com_fala = 0
            chunks_silencio = 0
            chunks_totais = 0

            while True:
                dados = processo.stdout.read(BYTES_POR_CHUNK)

                if not dados:
                    break

                nivel = calcular_rms(dados)

                if not fala_detectada:
                    pre_roll.append(dados)

                    if nivel > limite_voz:
                        chunks_com_fala += 1
                    else:
                        chunks_com_fala = 0

                    if chunks_com_fala >= 3:
                        fala_detectada = True
                        audio_gravado.extend(list(pre_roll))
                        audio_gravado.append(dados)
                        chunks_silencio = 0

                else:
                    audio_gravado.append(dados)
                    chunks_totais += 1

                    if nivel > limite_voz:
                        chunks_silencio = 0
                    else:
                        chunks_silencio += 1

                    if chunks_silencio >= WAKE_CHUNKS_SILENCIO_FINAL:
                        break

                    if chunks_totais >= WAKE_CHUNKS_MAXIMOS:
                        break

            if not fala_detectada:
                continue

            salvar_wav_em(ARQUIVO_WAKE, audio_gravado)

        finally:
            encerrar_microfone(processo)

        texto_wake = transcrever_wake()

        detectado, score, palavra = detectar_jarvis_no_texto(
            texto_wake
        )

        if not detectado:
            print(
                f"💤 Não era Jarvis "
                f"(melhor aproximação: '{palavra}', {score:.2f})."
            )
            continue

        print(
            f"🔔 Jarvis detectado "
            f"(aproximação: '{palavra}', {score:.2f})."
        )

        return texto_wake


# =========================================================
# ESCUTA SEM NOVO WAKE WORD
# =========================================================

def gravar_com_vad(espera_segundos):
    processo = iniciar_microfone()

    try:
        niveis_ruido = []

        for _ in range(CHUNKS_CALIBRACAO):
            dados = processo.stdout.read(BYTES_POR_CHUNK)
            if not dados:
                break
            niveis_ruido.append(calcular_rms(dados))

        ruido_medio = (
            sum(niveis_ruido) / len(niveis_ruido)
            if niveis_ruido
            else 100
        )
        limite_voz = max(250, ruido_medio * 2.7)

        pre_roll = deque(maxlen=CHUNKS_PRE_ROLL)
        audio_gravado = []

        fala_detectada = False
        chunks_com_fala = 0
        chunks_silencio = 0
        chunks_totais_fala = 0
        chunks_espera = 0
        limite_espera = int(espera_segundos * 1000 / CHUNK_MS)

        while True:
            dados = processo.stdout.read(BYTES_POR_CHUNK)
            if not dados:
                break

            nivel = calcular_rms(dados)

            if not fala_detectada:
                pre_roll.append(dados)
                chunks_espera += 1

                if nivel > limite_voz:
                    chunks_com_fala += 1
                else:
                    chunks_com_fala = 0

                if chunks_com_fala >= 3:
                    fala_detectada = True
                    audio_gravado.extend(list(pre_roll))
                    chunks_silencio = 0
                    print("🗣️ Fala detectada.")

                elif chunks_espera >= limite_espera:
                    return False

            else:
                audio_gravado.append(dados)
                chunks_totais_fala += 1

                if nivel > limite_voz:
                    chunks_silencio = 0
                else:
                    chunks_silencio += 1

                if chunks_silencio >= CHUNKS_SILENCIO_FINAL:
                    print("✅ Fim da fala.")
                    break

                if chunks_totais_fala >= CHUNKS_MAXIMOS_FALA:
                    break

        if not fala_detectada:
            return False

        salvar_wav(audio_gravado)
        return True

    finally:
        encerrar_microfone(processo)


def ouvir_sem_wake(espera_segundos):
    gravou = gravar_com_vad(espera_segundos)
    if not gravou:
        return ""
    return transcrever()


# =========================================================
# COMANDOS
# =========================================================

COMANDOS_ENCERRAMENTO = [
    "desligar sistema",
    "desliga sistema",
    "finalizar sistema",
    "finaliza sistema",
    "encerrar sistema",
    "encerra sistema",
    "fechar sistema",
    "fecha sistema",
    "desligar jarvis",
    "desliga jarvis",
    "finalizar jarvis",
    "finaliza jarvis",
    "encerrar jarvis",
    "encerra jarvis",
    "fechar jarvis",
    "fecha jarvis",
    "parar jarvis",
    "para jarvis",
    "sair do sistema",
    "sair do programa",
    "fechar programa",
    "encerrar programa",
    "finalizar programa",

    # Formas naturais preferidas por Sandro
    "ok pode repousar",
    "pode repousar",
    "repousar",
    "jarvis encerrar",
    "jarvis encerra",
    "encerrar programa",
    "jarvis desligar",
    "jarvis desliga",
]

PALAVRAS_ACAO_SAIDA = [
    "desligar",
    "desliga",
    "finalizar",
    "finaliza",
    "encerrar",
    "encerra",
    "fechar",
    "fecha",
    "parar",
    "para",
    "sair",
    "repousar",
    "repousa",
]

PALAVRAS_ALVO_SAIDA = [
    "sistema",
    "jarvis",
    "programa",
]


def palavra_parecida(palavra, opcoes, minimo=0.72):
    for opcao in opcoes:
        if palavra == opcao:
            return True

        if SequenceMatcher(None, palavra, opcao).ratio() >= minimo:
            return True

    return False


def e_comando_encerramento(comando):
    """
    Reconhecimento tolerante para saída.
    Aceita formas naturais como:
    - "ok pode repousar"
    - "Jarvis encerrar"
    - "encerrar programa"
    - "Jarvis desligar"
    além das formas já existentes.
    """
    n = normalizar_comando(comando)

    if not n:
        return False

    # Correspondência direta/contida com frases conhecidas.
    if any(frase in n for frase in COMANDOS_ENCERRAMENTO):
        return True

    palavras = n.split()

    # Evita interpretar frases longas normais como comando de saída.
    if len(palavras) > 7:
        return False

    # "repousar" funciona mesmo sem alvo explícito.
    if any(
        palavra_parecida(palavra, ["repousar", "repousa"], minimo=0.74)
        for palavra in palavras
    ):
        return True

    # "sair" sozinho também funciona.
    if len(palavras) <= 3 and any(
        palavra_parecida(palavra, ["sair"])
        for palavra in palavras
    ):
        return True

    tem_acao = any(
        palavra_parecida(palavra, PALAVRAS_ACAO_SAIDA)
        for palavra in palavras
    )

    tem_alvo = any(
        palavra_parecida(palavra, PALAVRAS_ALVO_SAIDA)
        for palavra in palavras
    )

    # Aceita "Jarvis encerrar/desligar/etc." mesmo sem dizer sistema/programa.
    menciona_jarvis = any(
        palavra_parecida(palavra, ["jarvis"], minimo=0.72)
        for palavra in palavras
    )

    if tem_acao and menciona_jarvis:
        return True

    return tem_acao and tem_alvo


RESPOSTAS_SIM = [
    "sim",
    "pode",
    "pode sim",
    "sim pode",
    "confirmo",
    "confirmado",
    "claro",
    "isso",
    "isso mesmo",
    "pode desligar",
    "pode encerrar",
    "pode repousar",
    "desligue",
    "pode ir",
]

RESPOSTAS_NAO = [
    "nao",
    "não",
    "nao pode",
    "não pode",
    "cancela",
    "cancelar",
    "continue",
    "continua",
    "continuar",
    "fica",
    "fique",
    "nao desligar",
    "não desligar",
    "nao desligue",
    "não desligue",
    "nao encerre",
    "não encerre",
]


def classificar_confirmacao(resposta):
    """
    Retorna:
      True  -> confirmou desligamento
      False -> cancelou
      None  -> resposta ambígua
    """
    n = normalizar_comando(resposta)

    if not n:
        return None

    # Negação sempre tem prioridade para evitar desligamento acidental.
    if any(frase in n for frase in [
        "nao",
        "cancela",
        "cancelar",
        "continua",
        "continuar",
        "fica",
        "fique",
    ]):
        return False

    # Correspondência direta com formas positivas.
    if n in {
        "sim",
        "pode",
        "pode sim",
        "sim pode",
        "confirmo",
        "confirmado",
        "claro",
        "isso",
        "isso mesmo",
        "pode desligar",
        "pode encerrar",
        "pode repousar",
        "desligue",
        "pode ir",
    }:
        return True

    palavras = n.split()

    # Tolerância para pequenas distorções do Whisper em respostas muito curtas.
    if len(palavras) <= 3:
        for palavra in palavras:
            if palavra_parecida(
                palavra,
                ["sim", "pode", "confirmo", "claro"],
                minimo=0.78,
            ):
                return True

            if palavra_parecida(
                palavra,
                ["nao", "cancela", "continua", "fica"],
                minimo=0.78,
            ):
                return False

    return None


def confirmar_encerramento():
    """
    Nunca encerra apenas por inferência.
    Depois de detectar intenção de saída, exige confirmação por voz.
    """
    falar(
        "Entendi que você quer encerrar. "
        "Posso me desligar? Sim ou não?"
    )

    for tentativa in range(2):
        print("❓ Aguardando confirmação: sim ou não...")

        resposta = ouvir_sem_wake(10)

        if not resposta:
            if tentativa == 0:
                falar("Não ouvi sua confirmação. Diga sim ou não.")
                continue

            falar(
                "Não consegui confirmar. "
                "Vou continuar online."
            )
            return False

        print(f"✅ Confirmação ouvida: {resposta}")

        decisao = classificar_confirmacao(resposta)

        if decisao is True:
            falar("Certo, Sandro. Vou repousar. Até logo.")
            return True

        if decisao is False:
            falar("Certo. Continuo online.")
            return False

        if tentativa == 0:
            falar("Não entendi. Diga apenas sim ou não.")
        else:
            falar(
                "Não consegui confirmar. "
                "Vou continuar online."
            )

    return False


# =========================================================
# AÇÕES CONTROLADAS NO WINDOWS
# =========================================================

def executar_powershell(script):
    """
    Executa apenas scripts construídos internamente pelo Jarvis.
    Não envia texto livre do usuário diretamente ao PowerShell.
    """
    try:
        resultado = subprocess.run(
            [
                "powershell.exe",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                script,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=12,
            check=False,
        )
        return resultado.returncode == 0

    except Exception as erro:
        print(f"[Erro ao executar ação no Windows: {erro}]")
        return False


def abrir_url(url):
    url_segura = url.replace("'", "''")
    return executar_powershell(
        f"Start-Process '{url_segura}'"
    )


def abrir_programa_windows(programa):
    """
    Programas permitidos. Nada de executar comandos arbitrários por voz.
    """
    executavel = CONFIG.get("programas", {}).get(programa)

    if not executavel:
        return False

    executavel = executavel.replace("'", "''")

    return executar_powershell(
        f"Start-Process '{executavel}'"
    )


def abrir_pasta_windows(nome):
    pasta = CONFIG.get("pastas", {}).get(nome)

    if not pasta:
        return False

    return executar_powershell(
        "$p = Join-Path $env:USERPROFILE "
        f"'{pasta}'; Start-Process explorer.exe -ArgumentList $p"
    )


def tecla_midia(codigo_vk, repeticoes=1):
    """
    Envia uma tecla multimídia predefinida ao Windows.
    """
    script = rf"""
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class JarvisMediaKeys {{
    [DllImport("user32.dll")]
    public static extern void keybd_event(
        byte bVk,
        byte bScan,
        uint dwFlags,
        UIntPtr dwExtraInfo
    );
}}
"@

1..{int(repeticoes)} | ForEach-Object {{
    [JarvisMediaKeys]::keybd_event(
        {int(codigo_vk)}, 0, 0, [UIntPtr]::Zero
    )
    Start-Sleep -Milliseconds 40
    [JarvisMediaKeys]::keybd_event(
        {int(codigo_vk)}, 0, 2, [UIntPtr]::Zero
    )
    Start-Sleep -Milliseconds 80
}}
"""
    return executar_powershell(script)


def extrair_pesquisa(comando_normalizado):
    """
    Extrai a consulta de frases como:
    'pesquise por bitcoin'
    'procure no google medicina chinesa'
    'buscar inteligência artificial'
    """
    padroes = [
        r"^(?:pesquise|pesquisar|busque|buscar|procure|procurar)\s+(?:por\s+)?(.+)$",
        r"^(?:pesquise|pesquisar|busque|buscar|procure|procurar)\s+(?:no|na)\s+(?:google|internet)\s+(?:por\s+)?(.+)$",
    ]

    for padrao in padroes:
        match = re.match(padrao, comando_normalizado)

        if match:
            consulta = match.group(1).strip()

            # Evita abrir busca vazia ou absurdamente curta.
            if len(consulta) >= 2:
                return consulta

    return ""


def acao_janela(acao):
    scripts = {
        "minimizar": "$wshell = New-Object -ComObject WScript.Shell; $wshell.SendKeys('% n')",
        "fechar": "$wshell = New-Object -ComObject WScript.Shell; $wshell.SendKeys('%{F4}')",
        "alternar": "$wshell = New-Object -ComObject WScript.Shell; $wshell.SendKeys('%{TAB}')",
        "maximizar": (
            "Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; "
            "public class JW { [DllImport(\"user32.dll\")] public static extern IntPtr GetForegroundWindow(); "
            "[DllImport(\"user32.dll\")] public static extern bool ShowWindow(IntPtr hWnd,int nCmdShow); }'; "
            "$h=[JW]::GetForegroundWindow(); [JW]::ShowWindow($h,3)"
        ),
    }

    script = scripts.get(acao)
    if not script:
        return False

    return executar_powershell(script)


def executar_item_rotina(item):
    tipo = item.get("tipo")
    alvo = item.get("alvo")

    if tipo == "site":
        url = CONFIG.get("sites", {}).get(alvo)
        return abrir_url(url) if url else False

    if tipo == "programa":
        return abrir_programa_windows(alvo)

    if tipo == "pasta":
        return abrir_pasta_windows(alvo)

    if tipo == "url":
        return abrir_url(alvo)

    return False


def executar_rotina(nome):
    rotina = CONFIG.get("rotinas", {}).get(nome)

    if not rotina:
        return False, 0, 0

    total = len(rotina)
    sucesso = 0

    for item in rotina:
        if executar_item_rotina(item):
            sucesso += 1
        time.sleep(0.35)

    return True, sucesso, total


def detectar_rotina(comando_normalizado):
    """
    Detecta rotinas de forma mais natural.
    Aceita, por exemplo:
    - começar trabalho
    - começar o trabalho
    - iniciar trabalho
    - iniciar o trabalho
    - modo consulta
    - iniciar modo consulta
    """

    comando = normalizar_comando(comando_normalizado)

    # Remove palavras de cortesia/apoio que o Whisper pode inserir.
    palavras_descartaveis = {
        "jarvis",
        "por",
        "favor",
        "agora",
        "o",
        "a",
        "os",
        "as",
        "meu",
        "minha",
    }

    palavras = [
        p for p in comando.split()
        if p not in palavras_descartaveis
    ]

    comando_limpo = " ".join(palavras)

    aliases = {
        "comecar trabalho": [
            "comecar trabalho",
            "iniciar trabalho",
            "comecar expediente",
            "iniciar expediente",
            "modo trabalho",
            "trabalho",
        ],
        "modo consulta": [
            "modo consulta",
            "iniciar consulta",
            "comecar consulta",
            "consulta",
        ],
        "modo estudo": [
            "modo estudo",
            "iniciar estudo",
            "comecar estudo",
            "estudo",
        ],
    }

    for nome in CONFIG.get("rotinas", {}):
        nome_normalizado = normalizar_comando(nome)

        candidatos = aliases.get(
            nome_normalizado,
            [nome_normalizado]
        )

        for candidato in candidatos:
            candidato = normalizar_comando(candidato)

            if (
                comando_limpo == candidato
                or candidato in comando_limpo
            ):
                return nome

    return ""


def numero_portugues_para_int(token):
    mapa = {
        "um": 1, "uma": 1, "dois": 2, "duas": 2, "tres": 3, "quatro": 4,
        "cinco": 5, "seis": 6, "sete": 7, "oito": 8, "nove": 9, "dez": 10,
        "onze": 11, "doze": 12, "treze": 13, "quatorze": 14, "catorze": 14,
        "quinze": 15, "dezesseis": 16, "dezessete": 17, "dezoito": 18,
        "dezenove": 19, "vinte": 20, "trinta": 30, "quarenta": 40,
        "cinquenta": 50, "sessenta": 60,
    }

    token = normalizar_comando(token).strip()

    if token.isdigit():
        return int(token)

    return mapa.get(token)


def extrair_temporizador(comando_normalizado):
    c = normalizar_comando(comando_normalizado)

    padrao = re.search(
        r"(?:timer|temporizador)(?:\s+de)?\s+([a-z0-9]+)\s+"
        r"(segundo|segundos|minuto|minutos|hora|horas)",
        c,
    )

    if not padrao:
        return None

    quantidade = numero_portugues_para_int(padrao.group(1))
    unidade = padrao.group(2)

    if not quantidade or quantidade <= 0:
        return None

    fator = 1
    if "minuto" in unidade:
        fator = 60
    elif "hora" in unidade:
        fator = 3600

    return quantidade * fator, quantidade, unidade


def callback_temporizador():
    falar("Sandro, seu temporizador terminou.")


def iniciar_temporizador(segundos, quantidade, unidade):
    timer = threading.Timer(segundos, callback_temporizador)
    timer.daemon = True
    temporizadores_ativos.append(timer)
    timer.start()

    unidade_falada = unidade
    falar(f"Temporizador iniciado para {quantidade} {unidade_falada}.")
    return True


def salvar_nota(texto_nota):
    texto_nota = texto_nota.strip()
    if not texto_nota:
        return False

    ARQUIVO_NOTAS.parent.mkdir(parents=True, exist_ok=True)

    carimbo = datetime.now().strftime("%d/%m/%Y %H:%M")

    with ARQUIVO_NOTAS.open("a", encoding="utf-8") as arquivo:
        arquivo.write(f"[{carimbo}] {texto_nota}\n")

    return True


def extrair_nota(comando_normalizado):
    c = comando_normalizado.strip()

    padroes = [
        r"^(?:anote|anotar)\s+(?:isso\s+)?(.+)$",
        r"^(?:faca|faça)\s+(?:uma\s+)?nota\s+(?:de\s+)?(.+)$",
        r"^(?:crie|criar)\s+(?:uma\s+)?nota\s+(?:de\s+)?(.+)$",
    ]

    for padrao in padroes:
        m = re.match(padrao, c, re.I)
        if m:
            return m.group(1).strip()

    return ""


def procurar_arquivo_windows(termo):
    termo = termo.strip()
    if not termo:
        return False

    termo_url = quote_plus(termo)
    url = f"search-ms:query={termo_url}"
    return abrir_url(url)


def copiar_para_clipboard_e_colar(texto):
    dados = base64.b64encode(texto.encode("utf-8")).decode("ascii")

    script = (
        "$t=[Text.Encoding]::UTF8.GetString("
        f"[Convert]::FromBase64String('{dados}')); "
        "Set-Clipboard -Value $t; "
        "$w=New-Object -ComObject WScript.Shell; "
        "Start-Sleep -Milliseconds 150; "
        "$w.SendKeys('^v')"
    )

    return executar_powershell(script)


def modo_ditado():
    falar("Modo ditado. Fale o texto que deseja escrever.")
    texto = ouvir_sem_wake(25)

    if not texto:
        falar("Não ouvi nenhum texto para ditar.")
        return True

    if copiar_para_clipboard_e_colar(texto):
        falar("Texto inserido.")
    else:
        falar("Não consegui inserir o texto.")

    return True


def extrair_busca_arquivo(comando_normalizado):
    c = normalizar_comando(comando_normalizado)

    padroes = [
        r"(?:procure|buscar|busque|localize)\s+(?:o\s+)?arquivo\s+(.+)$",
        r"(?:procure|buscar|busque|localize)\s+(?:nos\s+)?arquivos\s+(.+)$",
    ]

    for padrao in padroes:
        m = re.search(padrao, c)
        if m:
            return m.group(1).strip()

    return ""


def abrir_generico_configurado(comando_normalizado):
    c = normalizar_comando(comando_normalizado)

    m = re.match(
        r"^(?:abra|abrir|abre|inicie|iniciar)\s+(?:o\s+|a\s+)?(.+)$",
        c,
    )

    if not m:
        return False

    alvo = m.group(1).strip()

    # Sites
    for nome, url in CONFIG.get("sites", {}).items():
        nome_n = normalizar_comando(nome.replace("_", " "))
        if alvo == nome_n:
            if abrir_url(url):
                falar(f"Abrindo {nome_n}.")
            else:
                falar(f"Não consegui abrir {nome_n}.")
            return True

    # Programas
    aliases_programas = {
        "bloco_notas": ["bloco de notas", "notepad"],
        "calculadora": ["calculadora"],
        "explorador": ["explorador", "explorador de arquivos"],
        "paint": ["paint"],
        "chrome": ["chrome", "google chrome"],
    }

    for chave in CONFIG.get("programas", {}):
        nomes = aliases_programas.get(
            chave,
            [chave.replace("_", " ")]
        )

        if alvo in [normalizar_comando(n) for n in nomes]:
            if abrir_programa_windows(chave):
                falar(f"Abrindo {alvo}.")
            else:
                falar(f"Não consegui abrir {alvo}.")
            return True

    # Pastas
    for chave in CONFIG.get("pastas", {}):
        nomes = {
            "desktop": ["desktop", "area de trabalho"],
            "downloads": ["downloads"],
            "documentos": ["documentos"],
            "imagens": ["imagens", "fotos"],
            "musicas": ["musicas"],
            "videos": ["videos"],
        }.get(chave, [chave])

        if alvo in [normalizar_comando(n) for n in nomes]:
            if abrir_pasta_windows(chave):
                falar(f"Abrindo {alvo}.")
            else:
                falar(f"Não consegui abrir {alvo}.")
            return True

    return False


def tentar_comando_composto(comando_normalizado):
    """
    Divide apenas comandos claramente operacionais.
    Ex.: "abra calculadora e depois abra bloco de notas"
    """
    c = normalizar_comando(comando_normalizado)

    separadores = [" e depois ", " depois "]

    for sep in separadores:
        if sep in c:
            partes = [p.strip() for p in c.split(sep) if p.strip()]

            if 1 < len(partes) <= 3:
                sucesso = True

                for parte in partes:
                    if not processar_acao_windows(parte, parte):
                        sucesso = False
                        break

                return sucesso

    return False


def parece_comando_operacional(comando_normalizado):
    c = normalizar_comando(comando_normalizado)

    gatilhos = [
        "abra", "abrir", "abre",
        "feche", "fechar", "minimizar", "maximizar",
        "pesquise", "buscar", "busque", "procure", "localize",
        "timer", "temporizador",
        "anote", "nota",
        "ditado",
        "volume", "musica", "audio",
        "rotina", "modo trabalho", "modo consulta", "modo estudo",
        "atualizacao", "versao", "rollback",
    ]

    return any(g in c for g in gatilhos)



def processar_acao_windows(comando, comando_normalizado):
    """
    Retorna True se o comando foi tratado como ação do computador.
    """
    # -----------------------------------------------------
    # COMANDOS COMPOSTOS
    # -----------------------------------------------------
    if " e depois " in comando_normalizado or " depois " in comando_normalizado:
        if tentar_comando_composto(comando_normalizado):
            return True

    # -----------------------------------------------------
    # TEMPORIZADORES
    # -----------------------------------------------------
    info_timer = extrair_temporizador(comando_normalizado)

    if info_timer:
        segundos, quantidade, unidade = info_timer
        return iniciar_temporizador(segundos, quantidade, unidade)

    # -----------------------------------------------------
    # NOTAS RÁPIDAS
    # -----------------------------------------------------
    nota = extrair_nota(comando)

    if nota:
        if salvar_nota(nota):
            falar("Anotado.")
        else:
            falar("Não consegui salvar a nota.")
        return True

    # -----------------------------------------------------
    # MODO DITADO
    # -----------------------------------------------------
    if any(
        frase in comando_normalizado
        for frase in [
            "modo ditado",
            "iniciar ditado",
            "comecar ditado",
            "ditar texto",
        ]
    ):
        return modo_ditado()

    # -----------------------------------------------------
    # BUSCA LOCAL DE ARQUIVOS
    # -----------------------------------------------------
    termo_arquivo = extrair_busca_arquivo(comando_normalizado)

    if termo_arquivo:
        if procurar_arquivo_windows(termo_arquivo):
            falar(f"Procurando arquivos por {termo_arquivo}.")
        else:
            falar("Não consegui abrir a busca de arquivos.")
        return True

    # -----------------------------------------------------
    # ABERTURA NATURAL DE APPS / SITES / PASTAS
    # -----------------------------------------------------
    if abrir_generico_configurado(comando_normalizado):
        return True

    # -----------------------------------------------------
    # ROTINAS PERSONALIZADAS
    # -----------------------------------------------------
    nome_rotina = detectar_rotina(comando_normalizado)

    if nome_rotina:
        existe, sucesso, total = executar_rotina(nome_rotina)

        if existe:
            falar(
                f"Rotina {nome_rotina} iniciada. "
                f"{sucesso} de {total} ações executadas."
            )
            return True

    # -----------------------------------------------------
    # CONTROLE DA JANELA ATIVA
    # -----------------------------------------------------
    comandos_janela = [
        (["minimizar janela", "minimize a janela", "minimizar"], "minimizar", "Minimizando."),
        (["maximizar janela", "maximize a janela", "maximizar"], "maximizar", "Maximizando."),
        (["fechar janela", "feche a janela", "fechar janela ativa"], "fechar", "Fechando a janela."),
        (["alternar janela", "trocar janela", "proxima janela"], "alternar", "Alternando a janela."),
    ]

    for frases, acao, resposta in comandos_janela:
        if any(frase in comando_normalizado for frase in frases):
            if acao_janela(acao):
                falar(resposta)
            else:
                falar("Não consegui controlar a janela.")
            return True

    # -----------------------------------------------------
    # PESQUISA NA WEB
    # -----------------------------------------------------
    consulta = extrair_pesquisa(comando_normalizado)

    if consulta:
        url = (
            "https://www.google.com/search?q="
            + quote_plus(consulta)
        )

        if abrir_url(url):
            falar(f"Pesquisando por {consulta}.")
        else:
            falar("Não consegui abrir a pesquisa no navegador.")

        return True

    # -----------------------------------------------------
    # SITES
    # -----------------------------------------------------
    sites = CONFIG.get("sites", {})

    for nome, url in sites.items():
        if (
            f"abrir {nome}" in comando_normalizado
            or f"abra {nome}" in comando_normalizado
        ):
            if abrir_url(url):
                falar(f"Abrindo {nome}.")
            else:
                falar(f"Não consegui abrir {nome}.")

            return True

    if (
        "abrir navegador" in comando_normalizado
        or "abra o navegador" in comando_normalizado
        or comando_normalizado == "navegador"
    ):
        if abrir_url("https://www.google.com"):
            falar("Abrindo o navegador.")
        else:
            falar("Não consegui abrir o navegador.")

        return True

    # -----------------------------------------------------
    # PROGRAMAS
    # -----------------------------------------------------
    programas = [
        (
            ("bloco de notas", "notepad"),
            "bloco_notas",
            "o bloco de notas",
        ),
        (
            ("calculadora",),
            "calculadora",
            "a calculadora",
        ),
        (
            ("explorador de arquivos", "explorador"),
            "explorador",
            "o explorador de arquivos",
        ),
        (
            ("paint",),
            "paint",
            "o Paint",
        ),
        (
            ("chrome", "google chrome"),
            "chrome",
            "o Chrome",
        ),
    ]

    for nomes, chave, descricao in programas:
        if any(
            f"abrir {nome}" in comando_normalizado
            or f"abra {nome}" in comando_normalizado
            for nome in nomes
        ):
            if abrir_programa_windows(chave):
                falar(f"Abrindo {descricao}.")
            else:
                falar(f"Não consegui abrir {descricao}.")

            return True

    # Spotify via protocolo do Windows, se estiver instalado.
    if (
        "abrir spotify" in comando_normalizado
        or "abra spotify" in comando_normalizado
    ):
        if executar_powershell("Start-Process 'spotify:'"):
            falar("Abrindo o Spotify.")
        else:
            falar("Não consegui abrir o Spotify.")

        return True

    # -----------------------------------------------------
    # PASTAS
    # -----------------------------------------------------
    pastas = [
        (("downloads",), "downloads", "Downloads"),
        (("documentos",), "documentos", "Documentos"),
        (
            ("area de trabalho", "desktop"),
            "desktop",
            "Área de Trabalho",
        ),
        (("imagens", "fotos"), "imagens", "Imagens"),
        (("musicas", "musica"), "musicas", "Músicas"),
        (("videos", "video"), "videos", "Vídeos"),
    ]

    for nomes, chave, descricao in pastas:
        if any(
            f"abrir {nome}" in comando_normalizado
            or f"abra {nome}" in comando_normalizado
            for nome in nomes
        ):
            if abrir_pasta_windows(chave):
                falar(f"Abrindo {descricao}.")
            else:
                falar(f"Não consegui abrir {descricao}.")

            return True

    # -----------------------------------------------------
    # STATUS DO COMPUTADOR
    # -----------------------------------------------------
    if any(
        frase in comando_normalizado
        for frase in [
            "status do computador",
            "status do sistema",
            "como esta o computador",
        ]
    ):
        try:
            script = (
                "$os=Get-CimInstance Win32_OperatingSystem; "
                "$ramTotal=[math]::Round($os.TotalVisibleMemorySize/1MB,1); "
                "$ramFree=[math]::Round($os.FreePhysicalMemory/1MB,1); "
                "$ramUsada=[math]::Round($ramTotal-$ramFree,1); "
                "$disk=Get-CimInstance Win32_LogicalDisk -Filter \"DeviceID='C:'\"; "
                "$diskFree=[math]::Round($disk.FreeSpace/1GB,1); "
                "Write-Output (\"RAM={0}/{1};DISK={2}\" -f $ramUsada,$ramTotal,$diskFree)"
            )

            resultado = subprocess.run(
                ["powershell.exe", "-NoProfile", "-Command", script],
                capture_output=True,
                text=True,
                timeout=15,
            )

            saida = resultado.stdout.strip()

            if saida:
                falar(f"Status do computador: {saida}.")
            else:
                falar("Não consegui obter o status do computador.")
        except Exception:
            falar("Não consegui obter o status do computador.")

        return True

    # -----------------------------------------------------
    # CONTROLE DE MÍDIA
    # -----------------------------------------------------
    if any(
        frase in comando_normalizado
        for frase in [
            "pausar musica",
            "pause a musica",
            "pausar audio",
            "pausar midia",
            "dar pause",
            "pausa musica",
        ]
    ):
        tecla_midia(0xB3)  # VK_MEDIA_PLAY_PAUSE
        falar("Pausado.")
        return True

    if any(
        frase in comando_normalizado
        for frase in [
            "continuar musica",
            "continue a musica",
            "retomar musica",
            "retomar audio",
            "dar play",
            "tocar musica",
        ]
    ):
        tecla_midia(0xB3)
        falar("Continuando.")
        return True

    if any(
        frase in comando_normalizado
        for frase in [
            "proxima musica",
            "proxima faixa",
            "avancar musica",
            "pular musica",
        ]
    ):
        tecla_midia(0xB0)  # VK_MEDIA_NEXT_TRACK
        falar("Próxima.")
        return True

    if any(
        frase in comando_normalizado
        for frase in [
            "musica anterior",
            "faixa anterior",
            "voltar musica",
        ]
    ):
        tecla_midia(0xB1)  # VK_MEDIA_PREV_TRACK
        falar("Voltando.")
        return True

    if any(
        frase in comando_normalizado
        for frase in [
            "aumentar volume",
            "aumente o volume",
            "subir volume",
        ]
    ):
        tecla_midia(0xAF, repeticoes=3)  # VK_VOLUME_UP
        falar("Aumentando o volume.")
        return True

    if any(
        frase in comando_normalizado
        for frase in [
            "diminuir volume",
            "abaixar volume",
            "baixe o volume",
        ]
    ):
        tecla_midia(0xAE, repeticoes=3)  # VK_VOLUME_DOWN
        falar("Diminuindo o volume.")
        return True

    if any(
        frase in comando_normalizado
        for frase in [
            "silenciar",
            "silenciar volume",
            "silenciar som",
            "tirar o som",
            "mudo",
        ]
    ):
        tecla_midia(0xAD)  # VK_VOLUME_MUTE
        falar("Som alternado.")
        return True

    return False



# =========================================================
# ATUALIZAÇÃO ASSISTIDA / ROLLBACK
# =========================================================

def confirmar_acao_sim_nao(pergunta, espera=12):
    """
    Confirma ações administrativas. Se houver dúvida, cancela.
    """
    falar(pergunta)

    for tentativa in range(2):
        print("❓ Aguardando confirmação: sim ou não...")

        resposta = ouvir_sem_wake(espera)

        if not resposta:
            if tentativa == 0:
                falar("Não ouvi. Diga sim ou não.")
                continue
            return False

        print(f"✅ Confirmação ouvida: {resposta}")
        decisao = classificar_confirmacao(resposta)

        if decisao is True:
            return True

        if decisao is False:
            return False

        if tentativa == 0:
            falar("Não entendi. Diga apenas sim ou não.")

    return False


def reiniciar_jarvis():
    """
    Reinicia o processo atual usando o mesmo Python/venv.
    """
    caminho = str(BASE_DIR / "jarvis.py")
    print("🔄 Reiniciando Jarvis...")
    os.execv(
        sys.executable,
        [sys.executable, caminho]
    )


def tratar_atualizacao():
    """
    Procura atualização local em Downloads ou remota via manifest.
    Valida antes de pedir autorização.
    """
    falar("Vou verificar se existe uma atualização.")

    resultado = jarvis_updater.preparar_atualizacao(
        base_dir=BASE_DIR,
        config=CONFIG,
        versao_atual=VERSAO_JARVIS,
    )

    status = resultado.get("status")

    if status == "nenhuma":
        falar("Não encontrei uma versão mais nova.")
        return True

    if status == "erro":
        mensagem = resultado.get(
            "mensagem",
            "Não consegui preparar a atualização."
        )
        print(f"⚠️ Atualização: {mensagem}")
        falar("Encontrei um problema ao preparar a atualização. Não alterei o sistema.")
        return True

    versao = resultado.get("versao", "nova")
    origem = resultado.get("origem", "pacote")

    falar(
        f"Encontrei a versão {versao} e ela passou na validação inicial. "
        f"A origem é {origem}."
    )

    confirmou = confirmar_acao_sim_nao(
        f"Deseja instalar a versão {versao}? Sim ou não?"
    )

    if not confirmou:
        jarvis_updater.cancelar_preparacao(BASE_DIR)
        falar("Atualização cancelada. Continuo na versão atual.")
        return True

    instalado = jarvis_updater.aplicar_atualizacao(
        base_dir=BASE_DIR,
        versao_atual=VERSAO_JARVIS,
    )

    if not instalado.get("ok"):
        falar(
            "A instalação falhou e a versão atual foi preservada."
        )
        return True

    falar(
        f"Versão {versao} instalada e validada. "
        "Vou reiniciar agora."
    )
    reiniciar_jarvis()


def tratar_rollback():
    """
    Restaura o backup mais recente, sempre com confirmação.
    """
    info = jarvis_updater.info_ultimo_backup(BASE_DIR)

    if not info.get("existe"):
        falar("Não encontrei uma versão anterior disponível.")
        return True

    descricao = info.get("descricao", "a versão anterior")

    confirmou = confirmar_acao_sim_nao(
        f"Encontrei {descricao}. Deseja restaurar? Sim ou não?"
    )

    if not confirmou:
        falar("Restauração cancelada.")
        return True

    resultado = jarvis_updater.restaurar_ultimo_backup(BASE_DIR)

    if not resultado.get("ok"):
        falar("Não consegui restaurar a versão anterior.")
        return True

    falar("Versão anterior restaurada. Vou reiniciar.")
    reiniciar_jarvis()



def limpar_comando_operacional(comando):
    """
    Remove wake redundante, artigos e cortesias para comandos do próprio Jarvis.
    Isso permite frases naturais como:
    "Jarvis, verificar a atualização"
    "pode verificar se tem uma atualização?"
    """
    n = normalizar_comando(comando)

    palavras_descartaveis = {
        "jarvis", "ei", "hey", "oi",
        "por", "favor",
        "o", "a", "os", "as",
        "um", "uma",
        "me", "pra", "para",
        "pode", "poderia",
        "agora",
    }

    palavras = [
        p for p in n.split()
        if p not in palavras_descartaveis
    ]

    return " ".join(palavras)


def intencao_atualizacao(comando):
    c = limpar_comando_operacional(comando)
    palavras = c.split()

    tem_atualizacao = any(
        p.startswith("atualiza")
        or p in {"update", "versao", "versao"}
        for p in palavras
    )

    tem_verbo = any(
        p in {
            "verificar", "verifique",
            "procurar", "procure",
            "checar", "cheque",
            "buscar", "busque",
            "atualizar", "atualize",
            "tem", "ha", "existe",
        }
        for p in palavras
    )

    return tem_atualizacao and tem_verbo


def intencao_rollback(comando):
    c = limpar_comando_operacional(comando)

    gatilhos = [
        "voltar versao anterior",
        "restaurar versao anterior",
        "rollback",
        "desfazer atualizacao",
        "desfazer update",
        "versao anterior",
    ]

    return any(g in c for g in gatilhos)


def intencao_pergunta_versao(comando):
    c = limpar_comando_operacional(comando)

    return (
        "qual versao" in c
        or c == "versao"
        or "versao jarvis" in c
    )



def processar_comando(comando):
    comando = comando.strip()
    if not comando:
        return True

    # Se "Jarvis" for repetido durante a conversa contínua,
    # tratamos como wake e não mandamos para o Llama.
    if e_apenas_wake_word(comando):
        falar("Sim, Sandro.")
        return True

    # Remove wake redundante no início de qualquer comando.
    comando_sem_wake = remover_wake_word(comando)
    if comando_sem_wake:
        comando = comando_sem_wake

    print(f"Você disse: {comando}")
    comando_normalizado = normalizar_comando(comando)

    # Administração do próprio Jarvis com percepção mais natural.
    if intencao_atualizacao(comando):
        return tratar_atualizacao()

    if intencao_rollback(comando):
        return tratar_rollback()

    if intencao_pergunta_versao(comando):
        falar(f"Estou na versão {VERSAO_JARVIS}.")
        return True

    if e_comando_encerramento(comando):
        print("🛑 Intenção de encerramento reconhecida.")

        if confirmar_encerramento():
            return False

        return True

    # Hora - resposta local, sem Llama
    if (
        "que horas" in comando_normalizado
        or "qual a hora" in comando_normalizado
        or comando_normalizado == "horas"
    ):
        agora, _ = obter_data_hora_windows()
        resposta = f"São {agora.strftime('%H:%M')}."
        registrar_memoria("usuario", comando)
        registrar_memoria("jarvis", resposta)
        falar(resposta)
        return True

    # Data / dia da semana - relógio do Windows, sem Llama
    if (
        "que dia e hoje" in comando_normalizado
        or "que dia da semana" in comando_normalizado
        or "qual a data" in comando_normalizado
        or "data de hoje" in comando_normalizado
        or "dia da semana hoje" in comando_normalizado
    ):
        agora, indice_dia = obter_data_hora_windows()
        dia_semana = DIAS_SEMANA.get(indice_dia, "")
        resposta = (
            f"Hoje é {dia_semana}, dia {agora.strftime('%d/%m/%Y')}."
        )
        registrar_memoria("usuario", comando)
        registrar_memoria("jarvis", resposta)
        falar(resposta)
        return True

    if "seu nome" in comando_normalizado:
        resposta = "Meu nome é Jarvis."
        registrar_memoria("usuario", comando)
        registrar_memoria("jarvis", resposta)
        falar(resposta)
        return True

    # Ações reais no Windows são tratadas localmente.
    # Apenas ações previamente autorizadas no código podem ser executadas.
    if processar_acao_windows(
        comando,
        comando_normalizado,
    ):
        registrar_memoria("usuario", comando)
        registrar_memoria(
            "jarvis",
            "Comando executado no Windows."
        )
        return True

    # Se parece claramente um comando do sistema, não deixa o Llama inventar.
    if parece_comando_operacional(comando_normalizado):
        falar(
            "Entendi que isso é um comando, mas ainda não reconheci a ação exata. "
            "Tente reformular."
        )
        return True

    print("🧠 JARVIS: Pensando em streaming...")

    registrar_memoria("usuario", comando)

    resposta = pensar_e_falar_stream(comando)

    registrar_memoria("jarvis", resposta)

    return True


# =========================================================
# INICIALIZAÇÃO
# =========================================================

print("=" * 58)
print("JARVIS 8.1 - ASSISTENTE LOCAL | AÇÕES PRÁTICAS + UPDATE REMOTO")
print("=" * 58)
print("Wake word: Jarvis | reconhecimento pelo Whisper Small")
print("Conversa contínua: ativa")
print("Memória curta: ativa")
print("Streaming Llama → voz: ativo")
print("Saída: comandos naturais + confirmação por voz")
print("Controle do Windows: apps, arquivos, ditado, notas, timer, mídia e rotinas")
print("Config externa: jarvis_config.json")
print("Atualização assistida: ativa | rollback: ativo")

# O custo pesado acontece uma vez na inicialização, não na primeira pergunta.
aquecer_ollama()


# =========================================================
# LOOP PRINCIPAL
# =========================================================

executando = True

while executando:
    texto_ativacao = esperar_wake_e_capturar()
    print(f"🎧 Ativação ouvida: {texto_ativacao}")

    comando = remover_wake_word(texto_ativacao)

    # Se o Whisper ouviu apenas o chamado Jarvis,
    # não envia isso ao Llama.
    if not comando:
        falar("Sim, Sandro.")
        print("🎙️ Estou ouvindo sua pergunta...")

        comando = ouvir_sem_wake(ESPERA_PRIMEIRA_PERGUNTA)
        if not comando:
            print("💤 Nenhuma pergunta. Voltando ao modo de espera.")
            continue

    executando = processar_comando(comando)
    if not executando:
        break

    # Conversa contínua: cada nova fala reabre uma janela completa de 20 s.
    while executando:
        print("\n🟡 Pode continuar falando...")

        proximo_comando = ouvir_sem_wake(ESPERA_CONTINUACAO)
        if not proximo_comando:
            print("💤 Conversa encerrada. Voltando ao Jarvis.")
            break

        executando = processar_comando(proximo_comando)
        if not executando:
            break
