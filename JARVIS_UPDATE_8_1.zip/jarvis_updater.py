import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
import urllib.request
import zipfile

from pathlib import Path
from datetime import datetime


STAGE_DIRNAME = ".update_stage"
BACKUP_DIRNAME = "backups"
VERSION_FILENAME = "VERSION"


def _parse_version(v):
    numeros = re.findall(r"\d+", str(v))
    return tuple(int(x) for x in numeros) if numeros else (0,)


def _maior_que(nova, atual):
    return _parse_version(nova) > _parse_version(atual)


def _sha256(caminho):
    h = hashlib.sha256()
    with open(caminho, "rb") as f:
        for bloco in iter(lambda: f.read(1024 * 1024), b""):
            h.update(bloco)
    return h.hexdigest()


def _ler_json(caminho):
    with open(caminho, "r", encoding="utf-8") as f:
        return json.load(f)


def _downloads_windows():
    candidatos = []

    # Caminho conhecido deste computador
    candidatos.append(Path("/mnt/c/Users/sandr/Downloads"))

    # Fallback para outros usuários Windows
    users = Path("/mnt/c/Users")
    if users.exists():
        try:
            for p in users.iterdir():
                d = p / "Downloads"
                if d.exists():
                    candidatos.append(d)
        except Exception:
            pass

    vistos = set()
    saida = []
    for p in candidatos:
        s = str(p)
        if s not in vistos and p.exists():
            vistos.add(s)
            saida.append(p)
    return saida


def _encontrar_pacotes_locais():
    encontrados = []
    padroes = [
        "JARVIS_UPDATE_*.zip",
        "JARVIS_*.zip",
    ]

    for pasta in _downloads_windows():
        for padrao in padroes:
            for arquivo in pasta.glob(padrao):
                if arquivo.is_file():
                    encontrados.append(arquivo)

    # Mais recentes primeiro
    encontrados.sort(
        key=lambda p: p.stat().st_mtime,
        reverse=True
    )
    return encontrados


def _baixar_manifest_e_pacote(config, destino, versao_atual):
    updates = config.get("updates", {}) if isinstance(config, dict) else {}
    manifest_url = str(updates.get("manifest_url", "")).strip()

    if not manifest_url:
        return None, None

    req = urllib.request.Request(
        manifest_url,
        headers={"User-Agent": "Jarvis-Updater/1.1"},
    )

    with urllib.request.urlopen(req, timeout=20) as r:
        manifest = json.loads(r.read().decode("utf-8"))

    version = str(manifest.get("version", "")).strip()
    package_url = str(manifest.get("package_url", "")).strip()
    sha256_esperado = str(manifest.get("sha256", "")).strip().lower()

    if not version:
        raise RuntimeError("Manifest remoto sem version.")

    # Se já estamos na mesma versão ou acima, não baixa nada.
    if not _maior_que(version, versao_atual):
        return None, {
            "status": "nenhuma",
            "version": version,
        }

    if not package_url or not sha256_esperado:
        raise RuntimeError(
            "Manifest remoto incompleto: package_url e sha256 são obrigatórios."
        )

    pacote = destino / f"remote_update_{version}.zip"

    req2 = urllib.request.Request(
        package_url,
        headers={"User-Agent": "Jarvis-Updater/1.1"},
    )

    with urllib.request.urlopen(req2, timeout=60) as r, open(pacote, "wb") as f:
        shutil.copyfileobj(r, f)

    sha_real = _sha256(pacote).lower()

    if sha_real != sha256_esperado:
        pacote.unlink(missing_ok=True)
        raise RuntimeError("SHA-256 do pacote remoto não confere.")

    return pacote, {
        "status": "nova",
        "version": version,
    }


def _extrair_validar(pacote, stage_dir, versao_atual):
    if stage_dir.exists():
        shutil.rmtree(stage_dir)

    stage_dir.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(pacote, "r") as z:
        nomes = set(z.namelist())

        # Impede caminhos perigosos no ZIP
        for nome in nomes:
            alvo = (stage_dir / nome).resolve()
            if not str(alvo).startswith(str(stage_dir.resolve())):
                raise RuntimeError("Pacote contém caminho inválido.")

        z.extractall(stage_dir)

    versao_path = stage_dir / VERSION_FILENAME
    jarvis_path = stage_dir / "jarvis.py"

    if not versao_path.exists() or not jarvis_path.exists():
        raise RuntimeError("Pacote sem VERSION ou jarvis.py.")

    versao = versao_path.read_text(encoding="utf-8").strip()

    if not _maior_que(versao, versao_atual):
        raise RuntimeError(
            f"A versão {versao} não é mais nova que {versao_atual}."
        )

    # Validação de sintaxe sem importar o arquivo
    import py_compile
    py_compile.compile(str(jarvis_path), doraise=True)

    updater_path = stage_dir / "jarvis_updater.py"
    if updater_path.exists():
        py_compile.compile(str(updater_path), doraise=True)

    meta = {
        "versao": versao,
        "pacote": str(pacote),
    }
    (stage_dir / "stage_meta.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    return meta


def preparar_atualizacao(base_dir, config, versao_atual):
    base_dir = Path(base_dir)
    stage_dir = base_dir / STAGE_DIRNAME

    try:
        # 1) Se houver manifest remoto configurado, tenta primeiro
        temp_dir = Path(tempfile.mkdtemp(prefix="jarvis_update_"))
        try:
            pacote_remoto, info_remota = _baixar_manifest_e_pacote(
                config,
                temp_dir,
                versao_atual,
            )

            if info_remota and info_remota.get("status") == "nenhuma":
                return {"status": "nenhuma"}

            if pacote_remoto:
                meta = _extrair_validar(
                    pacote_remoto,
                    stage_dir,
                    versao_atual
                )
                return {
                    "status": "pronta",
                    "versao": meta["versao"],
                    "origem": "GitHub",
                }
        finally:
            # O pacote já foi extraído para stage; temp pode ser removido
            shutil.rmtree(temp_dir, ignore_errors=True)

        # 2) Fallback local: Downloads
        for pacote in _encontrar_pacotes_locais():
            try:
                meta = _extrair_validar(
                    pacote,
                    stage_dir,
                    versao_atual
                )
                return {
                    "status": "pronta",
                    "versao": meta["versao"],
                    "origem": "pasta Downloads",
                }
            except Exception:
                continue

        return {"status": "nenhuma"}

    except Exception as erro:
        return {
            "status": "erro",
            "mensagem": str(erro),
        }


def cancelar_preparacao(base_dir):
    stage_dir = Path(base_dir) / STAGE_DIRNAME
    shutil.rmtree(stage_dir, ignore_errors=True)


def _backup_atual(base_dir, versao_atual):
    base_dir = Path(base_dir)
    raiz = base_dir / BACKUP_DIRNAME
    raiz.mkdir(parents=True, exist_ok=True)

    carimbo = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = raiz / f"{carimbo}_v{versao_atual}"
    backup.mkdir(parents=True, exist_ok=False)

    for nome in [
        "jarvis.py",
        "jarvis_config.json",
        "jarvis_updater.py",
        VERSION_FILENAME,
    ]:
        origem = base_dir / nome
        if origem.exists():
            shutil.copy2(origem, backup / nome)

    return backup


def aplicar_atualizacao(base_dir, versao_atual):
    base_dir = Path(base_dir)
    stage_dir = base_dir / STAGE_DIRNAME

    meta_path = stage_dir / "stage_meta.json"
    if not meta_path.exists():
        return {"ok": False, "erro": "Nenhuma atualização preparada."}

    meta = _ler_json(meta_path)
    versao_nova = str(meta.get("versao", "")).strip()

    backup = None

    try:
        backup = _backup_atual(base_dir, versao_atual)

        # Arquivos permitidos a serem substituídos
        permitidos = [
            "jarvis.py",
            "jarvis_config.json",
            "jarvis_updater.py",
            VERSION_FILENAME,
        ]

        for nome in permitidos:
            origem = stage_dir / nome
            if not origem.exists():
                continue

            destino = base_dir / nome
            temporario = base_dir / f".{nome}.novo"

            shutil.copy2(origem, temporario)
            os.replace(temporario, destino)

        # Valida novamente já no destino
        import py_compile
        py_compile.compile(
            str(base_dir / "jarvis.py"),
            doraise=True
        )

        if (base_dir / "jarvis_updater.py").exists():
            py_compile.compile(
                str(base_dir / "jarvis_updater.py"),
                doraise=True
            )

        shutil.rmtree(stage_dir, ignore_errors=True)

        return {
            "ok": True,
            "versao": versao_nova,
            "backup": str(backup),
        }

    except Exception as erro:
        # Rollback automático se algo falhar durante a aplicação
        if backup and backup.exists():
            for arquivo in backup.iterdir():
                if arquivo.is_file():
                    shutil.copy2(
                        arquivo,
                        base_dir / arquivo.name
                    )

        return {
            "ok": False,
            "erro": str(erro),
        }


def _listar_backups(base_dir):
    raiz = Path(base_dir) / BACKUP_DIRNAME
    if not raiz.exists():
        return []

    backups = [
        p for p in raiz.iterdir()
        if p.is_dir()
    ]

    backups.sort(
        key=lambda p: p.stat().st_mtime,
        reverse=True
    )
    return backups


def info_ultimo_backup(base_dir):
    backups = _listar_backups(base_dir)

    if not backups:
        return {"existe": False}

    ultimo = backups[0]
    return {
        "existe": True,
        "caminho": str(ultimo),
        "descricao": f"o backup {ultimo.name}",
    }


def restaurar_ultimo_backup(base_dir):
    base_dir = Path(base_dir)
    backups = _listar_backups(base_dir)

    if not backups:
        return {"ok": False, "erro": "Sem backup."}

    backup = backups[0]

    try:
        # Preserva a versão corrente antes do rollback
        versao_atual = "desconhecida"
        vf = base_dir / VERSION_FILENAME
        if vf.exists():
            versao_atual = vf.read_text(
                encoding="utf-8"
            ).strip() or versao_atual

        _backup_atual(base_dir, f"antes_rollback_{versao_atual}")

        for arquivo in backup.iterdir():
            if arquivo.is_file():
                shutil.copy2(
                    arquivo,
                    base_dir / arquivo.name
                )

        import py_compile
        py_compile.compile(
            str(base_dir / "jarvis.py"),
            doraise=True
        )

        return {"ok": True, "backup": str(backup)}

    except Exception as erro:
        return {"ok": False, "erro": str(erro)}
