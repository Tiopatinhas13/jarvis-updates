import base64
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

REPO = "Tiopatinhas13/jarvis-updates"
BRANCH = "main"


def _run(args, timeout=60):
    return subprocess.run(
        args,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )


def verificar_prontidao():
    if shutil.which("gh") is None:
        return {"ok": False, "mensagem": "GitHub CLI não está instalado."}

    r = _run(["gh", "auth", "status"], timeout=20)

    if r.returncode != 0:
        return {"ok": False, "mensagem": "GitHub CLI não está autenticado."}

    return {"ok": True}


def _downloads():
    caminhos = [Path("/mnt/c/Users/sandr/Downloads")]
    users = Path("/mnt/c/Users")

    if users.exists():
        try:
            for usuario in users.iterdir():
                d = usuario / "Downloads"
                if d.exists():
                    caminhos.append(d)
        except Exception:
            pass

    unicos = []
    vistos = set()

    for p in caminhos:
        s = str(p)
        if p.exists() and s not in vistos:
            vistos.add(s)
            unicos.append(p)

    return unicos


def _versao_do_nome(nome):
    m = re.search(r"JARVIS_UPDATE_([0-9_\.]+)\.zip$", nome, re.I)
    if not m:
        return ""
    return m.group(1).replace("_", ".")


def _tupla_versao(v):
    nums = re.findall(r"\d+", str(v))
    return tuple(int(x) for x in nums) if nums else (0,)


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for bloco in iter(lambda: f.read(1024 * 1024), b""):
            h.update(bloco)
    return h.hexdigest()


def _manifest_para(pasta, versao):
    nomes = [
        "manifest.json",
        f"manifest_{versao.replace('.', '_')}.json",
        f"manifest_{versao}.json",
    ]

    candidatos = [pasta / n for n in nomes]
    candidatos += list(pasta.glob("manifest*.json"))

    vistos = set()

    for p in candidatos:
        if str(p) in vistos or not p.exists():
            continue

        vistos.add(str(p))

        try:
            dados = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue

        if str(dados.get("version", "")).strip() == versao:
            return p, dados

    return None, None


def preparar_publicacao():
    pacotes = []

    for pasta in _downloads():
        for p in pasta.glob("JARVIS_UPDATE_*.zip"):
            versao = _versao_do_nome(p.name)
            if versao:
                pacotes.append((versao, p))

    if not pacotes:
        return {
            "ok": False,
            "mensagem": "Nenhum pacote JARVIS_UPDATE encontrado em Downloads."
        }

    pacotes.sort(key=lambda x: _tupla_versao(x[0]), reverse=True)

    for versao, pacote in pacotes:
        manifest_path, manifest = _manifest_para(pacote.parent, versao)

        if manifest_path is None:
            continue

        sha_real = _sha256(pacote)
        sha_manifest = str(manifest.get("sha256", "")).strip().lower()

        if sha_real.lower() != sha_manifest:
            continue

        return {
            "ok": True,
            "versao": versao,
            "pacote": str(pacote),
            "pacote_nome": pacote.name,
            "manifest": str(manifest_path),
        }

    return {
        "ok": False,
        "mensagem": (
            "Encontrei pacote, mas não achei manifest compatível "
            "com SHA-256 válido."
        ),
    }


def _sha_remoto(remote_path):
    r = _run(
        [
            "gh",
            "api",
            f"repos/{REPO}/contents/{remote_path}?ref={BRANCH}",
        ],
        timeout=30,
    )

    if r.returncode != 0:
        return None

    try:
        return json.loads(r.stdout).get("sha")
    except Exception:
        return None


def _enviar_arquivo(local_path, remote_path, mensagem):
    local_path = Path(local_path)

    conteudo = base64.b64encode(local_path.read_bytes()).decode("ascii")
    sha = _sha_remoto(remote_path)

    args = [
        "gh",
        "api",
        "--method",
        "PUT",
        f"repos/{REPO}/contents/{remote_path}",
        "-f",
        f"message={mensagem}",
        "-f",
        f"content={conteudo}",
        "-f",
        f"branch={BRANCH}",
    ]

    if sha:
        args += ["-f", f"sha={sha}"]

    r = _run(args, timeout=120)

    if r.returncode != 0:
        erro = (r.stderr or r.stdout).strip()
        return False, erro

    return True, ""


def publicar(preparo):
    pronto = verificar_prontidao()

    if not pronto.get("ok"):
        return pronto

    if not preparo.get("ok"):
        return {"ok": False, "mensagem": "Publicação não preparada."}

    versao = preparo["versao"]
    pacote = Path(preparo["pacote"])
    manifest = Path(preparo["manifest"])

    ok, erro = _enviar_arquivo(
        pacote,
        pacote.name,
        f"JARVIS {versao} - pacote",
    )

    if not ok:
        return {"ok": False, "mensagem": f"Falha no pacote: {erro}"}

    ok, erro = _enviar_arquivo(
        manifest,
        "manifest.json",
        f"JARVIS {versao} - manifest",
    )

    if not ok:
        return {
            "ok": False,
            "mensagem": "Pacote publicado, mas falhou manifest.json: " + erro
        }

    return {"ok": True, "versao": versao}
